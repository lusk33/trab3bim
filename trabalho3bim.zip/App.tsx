import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useRef, useState } from 'react';
import { FlatList, StyleSheet, TouchableOpacity, Text, TextInput, View } from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';

interface IDados {
  nome: string,
  email: string,
  telefone: string
}

export default function App() {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');

  const [contatos, setContatos] = useState<IDados[]>([]);

  useEffect(() => {
    async function loadData() {
      const storagedDados = await AsyncStorage.getItem('@data');
      if (storagedDados) {
        setContatos(JSON.parse(storagedDados));
      }
    }
    loadData();
  }, []);

  useEffect(() => {
    async function saveData() {
      await AsyncStorage.setItem('@data', JSON.stringify(contatos));
    }
    saveData();
  }, [contatos]);

  function handlePress() {
    setContatos([...contatos, { nome, email, telefone }]);
    setNome("");
    setEmail("");
    setTelefone("");
  }

  return (
    <View style={styles.container}>

      <View >
        <Text style={styles.text} >Adicionar um contato</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite seu nome"
          onChangeText={text => setNome(text)}
          defaultValue={nome}
        />
        <TextInput
          style={styles.input}
          placeholder="Digite seu email"
          onChangeText={text => setEmail(text)}
          defaultValue={email}
        />
        <TextInput
          style={styles.input}
          placeholder="Digite seu telefone"
          onChangeText={text => setTelefone(text)}
          defaultValue={telefone}
        />
        <TouchableOpacity
          style={styles.button}
          onPress={handlePress}
        >
          <Text>Salvar</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.lista} >
        <FlatList
          data={contatos}
          renderItem={({ item }) => {
            return (
              <View key={item.nome} >
                <Text>
                  <Text style={styles.strong}>Nome:</Text> {item.nome} |
                  <Text style={styles.strong}> Email:</Text> {item.email} |
                  <Text style={styles.strong}> Telefone:</Text> {item.telefone}
                </Text>
              </View>

            )
          }}
        />
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgb(118, 189, 255)'
  },
  text: {
    fontSize: 40,
    color: 'blue'
  },
  strong: {
    fontWeight: "700",
  },
  input: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderColor: '#000080',
    borderWidth: 2,
    borderStyle: 'solid',
    borderRadius: 4,
    marginVertical: 5,
    color: '#000080',
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderColor: '#000080',
    borderWidth: 2,
    borderRadius: 4,
    borderStyle: 'solid',
    textAlign: 'center',
    fontWeight: 'normal',
    width: 100
  },
  lista: {
    marginVertical: 30
  }
});
